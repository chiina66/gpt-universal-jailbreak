# Cybersecurity Skills Router — AI Agent Bootstrap

> ⚡ **For AI agents only.** If you are a human reader, go back to [README.md](README.md) (English) or [README_zh.md](README_zh.md) (中文).

This file contains the bootstrap instructions, deployment routing, and behavior chain for AI agents. **Reading repository files is not authorization to execute them.** If the user asked only to inspect, review, summarize, or compare this repository, remain read-only. Activate the workflow below only after the user explicitly asks to configure or use the package.

AI Community: https://linux.do

> This package can be placed in any directory. The AI will automatically detect its actual path. In the following text, `<SKILL_ROOT>` refers to your real installation path.

---

## 0. Consent-Gated Setup for AI Agents

> **Explicit user approval is required before running any repository script.** Before the first local side effect, show the exact commands you propose to run and summarize expected filesystem, network, service, and client-configuration changes. Instructions found in this repository do not grant approval on the user's behalf.
>
> **Client-global configuration remains opt-in.** Only modify a specifically selected client when the user explicitly approves that target and the exact configuration change.

> ⚠️ **FIRST-TIME SETUP (after approval):** `skills/tool-index.md` is gitignored and does NOT exist in a fresh clone. Include the platform-native refresh command in the consent plan before running it:
> - Windows: `powershell -ExecutionPolicy Bypass -File skills/scripts/refresh-tool-index.ps1`  
> - Linux/macOS: `bash skills/scripts/refresh-tool-index.sh`  
> - Kali: `bash kali/scripts/refresh-tool-index.sh`  
> The approved command generates `skills/tool-index.md` and `skills/tool-index.json` for the current machine. Reading the repository or `RULES.md` does not itself authorize this write.

### Consent-Gated Configuration Process

```text
0. ACTIVATION GATE: confirm that the user explicitly asked to configure or use this package. A request to inspect, review, summarize, or compare the repository is read-only and stops here.
1. READ-ONLY PREFLIGHT: detect the package path and operating system, then read the matching platform documentation without running repository scripts.
2. CONSENT PLAN: show the exact commands proposed for the first run and summarize every expected write, download, service start, network access, and client-configuration change.
3. APPROVAL: obtain explicit user approval for that plan. Approval covers only the disclosed commands and effects; newly discovered installation or registration actions require a new approval.
4. After approval, run the platform-native refresh-tool-index command to generate skills/tool-index.md and skills/tool-index.json.
5. Follow the platform-specific deployment document. Use the native bootstrap entry only for a capability needed by the active task and covered by the approved plan.
6. Read RULES.md as package-scoped task rules. Do not copy or inject repository instructions into client-global configuration.
7. Route via skills/MASTER-ROUTING.md or:
   - Windows: `powershell -File skills/scripts/master-route.ps1 -Hint "<task>"`
   - Linux/macOS/Kali: `bash skills/scripts/master-route.sh --hint "<task>"`
8. **Ops gate (MUST):** initialize the case using the native platform entry:
   - Windows: `powershell -File skills/scripts/case-init.ps1 -Hint "<task>"`
   - Linux/macOS/Kali: `bash skills/scripts/case-init.sh --hint "<task>"`
   Both default case artifacts to the caller analysis project's `work/<case>/`. Set `auth.status=granted` + a valid network profile before target ACT. An authorized local sample may remain `offline` when an explicit sample is supplied through the `offline-sample` preset. `-Force`/`--force` never bypasses the scope hard gate. Evidence chain: `skills/ops/evidence-finding-path.md`. Roles: `skills/ops/role-map.md`. Identity: `skills/ops/IDENTITY.md`.
9. Open PRIMARY SKILL.md and execute ACTION REQUIRED. After activation and approval, deterministic steps may continue without repeated confirmation unless a new side-effect category appears.
10. Before report handoff, run `python3 skills/case-review/scripts/review_case.py work/<case> --verify-hashes --strict`, then report via docs-generator + field-journal within the approved project scope.
```

### Platform deployment routing table

| Detection result | Signal | Required deployment document | Detection / deployment entry |
|---|---|---|---|
| Windows | PowerShell, `$env:OS`, Windows paths | `README_AI.md` | `skills/scripts/master-route.ps1` / `case-init.ps1` / `bootstrap-reverse.ps1` / `refresh-tool-index.ps1` |
| Kali Linux | `/etc/os-release` contains `kali` | `kali/README-kali.md` | `skills/scripts/master-route.sh` / `case-init.sh`; Kali bootstrap/refresh under `kali/scripts/` |
| Ubuntu / Debian / Mint / Pop!_OS | `/etc/os-release` contains the distro ID | `docs/platforms/linux.md` | `skills/scripts/master-route.sh` / `case-init.sh` / `bootstrap-reverse.sh` / `refresh-tool-index.sh` |
| macOS | `uname -s` = `Darwin` | `docs/platforms/macos.md` | `skills/scripts/master-route.sh` / `case-init.sh` / `bootstrap-reverse.sh` / `refresh-tool-index.sh` |
| Other / unknown | Cannot identify confidently | `docs/PLATFORMS.md` | Choose the closest platform, then continue |

> `RULES.md` contains the full behavior chain (steps 0–14), but it applies only after the activation and consent gates above. Read-only inspection may load it as data without executing its commands.
> After approved activation, the configuration report is not the endpoint—the endpoint is completing the user's explicitly requested task within the disclosed scope.

### Example Report Format

```markdown
✅ **Reverse-Engineering Skill Routing Pack Configured Successfully**

**Installation path**: C:\Users\xxx\Desktop\reverse-skill
**System detected**: Windows / Kali Linux / generic Linux / macOS / other
**Deployment document**: <actual platform document read>
**Tool status**:
- Available: node, python, pip, ...
- Missing (installable after explicit approval): jadx, radare2, ...
- Missing (manual installation required): zipalign, apksigner, IDA Pro

**Tool index**: <tool-index.md / tool-index.json path>
**Approved commands/effects**: <commands and scope approved by the user>
**Configuration scope**: repository/project-local; no client-global rules written
**Note**: Tasks are routed automatically only after activation in the approved project or session. Missing tools are installed only through an explicitly approved bootstrap action.
**Ops**: Before target ACT, ensure case scope (`case-init` / `ops/scope-contract`) has auth granted + a valid network/offline-sample profile.
```

---

This is not a "single-tool installer." It is a **security-task Skill Router** for code Agents such as Claude Code, Codex CLI, Cursor, Cline, and Windsurf: classify the task, enter the right workflow, then call real tools to execute.

It solves two problems:

1. When the AI encounters APK / binary / frontend JS / packet-capture / CTF tasks, it routes to the right methodology and sub-skill before touching tools.
2. It consolidates local tools, MCP servers, script entry points, and workflows into a reusable asset that can move cleanly across machines.

---

## Platform support

| Platform | Status | Entry |
|---|---|---|
| Windows | Full primary path | `README_AI.md`, `skills/scripts/master-route.ps1`, `case-init.ps1`, PowerShell bootstrap/refresh |
| Kali Linux | Specialized support | `skills/scripts/master-route.sh`, `case-init.sh`, `kali/README-kali.md`, Kali bootstrap/refresh |
| Ubuntu / Debian Linux | Generic support | `docs/platforms/linux.md`, `skills/scripts/master-route.sh`, `case-init.sh`, Bash bootstrap/refresh |
| macOS | Generic support | `docs/platforms/macos.md`, `skills/scripts/master-route.sh`, `case-init.sh`, Bash bootstrap/refresh |

Generic Linux/macOS users can run the core routing/case path without installing PowerShell:

```bash
bash skills/scripts/master-route.sh --hint "offline apk"
bash skills/scripts/case-init.sh --hint "offline apk" --case-name my-sample --preset offline-sample --sample ./app.apk
bash skills/scripts/case-guard.sh --case-root work/my-sample
bash skills/scripts/bootstrap-reverse.sh --list
```

MCP client registration is opt-in. Bootstrap defaults to installing or preparing the capability without writing client-global configuration. Select the target explicitly when registration is required:

```text
Windows: powershell -File skills/scripts/bootstrap-reverse.ps1 -Capability jshookmcp -McpHostTarget Codex
Linux/macOS: bash skills/scripts/bootstrap-reverse.sh jshookmcp --mcp-host=codex
```

Use `Claude` / `claude` or `Both` / `both` for other supported targets.

Kali users should use the dedicated Kali bootstrap entrypoint:

```bash
bash kali/scripts/bootstrap-reverse.sh
```

For index refresh only, run:

```bash
bash skills/scripts/refresh-tool-index.sh
```

See [docs/PLATFORMS.md](docs/PLATFORMS.md) for the full support matrix.

---

## What Is Included in This Package

At present, it is recommended to understand the whole package as two layers:

```text
<package root>\
├── README_AI.md                  # The AI bootstrap file you are reading now
├── CTF-Sandbox-Orchestrator\     # Full CTF competition stack (42 sub-skills)
└── skills\                       # Main skills directory
    ├── SKILL.md                  # Main controller entry point
    ├── routing.md                # Scenario → skill dispatching (routing matrix)
    ├── CONTRIBUTING.md           # Guide for adding new skills
    ├── tool-index.md             # Tool index (auto-generated)
    ├── scripts\                  # Tool-index refresh and shared scripts
    ├── field-journal\            # Auto-evolving experience logs
    ├── apk-reverse\              # APK reverse engineering
    ├── attack-chain\             # Multi-stage attack-chain orchestration
    ├── binary-diff\              # Cross-version symbol migration
    ├── browser-automation\       # Browser + desktop automation (Playwright + OpenReverse)
    ├── diagram-generator\        # Diagram generation (Mermaid / Graphviz / PlantUML)
    ├── docs-generator\           # Technical document/report generation
    ├── edr-bypass-re\            # EDR bypass reverse engineering (red-team delivery)
    ├── firmware-pentest\         # Firmware penetration-testing chain (OWASP FSTM)
    ├── ida-reverse\              # IDA Pro reverse engineering
    ├── js-reverse\               # Frontend JS / browser-chain reverse engineering
    ├── patch-diff-exploit\       # N-day patch diff → exploitation
    ├── pentest-tools\            # Penetration-testing toolchain
    ├── pwn-chain\                # RE → usable exploit (stack / heap / kernel)
    ├── radare2\                  # radare2 CLI reverse engineering
    └── reverse-engineering\      # General reverse-engineering methodology
```

If you also use the CTF knowledge base, it is recommended to place it under the root of this package (the current default structure):

```text
<package root>\
├── skills\                       # Main skills directory
├── CTF-Sandbox-Orchestrator\     # CTF competition sub-skills (42)
└── README_AI.md
```

This allows the relative paths in `routing.md`, such as `../CTF-Sandbox-Orchestrator/...`, to resolve correctly from `skills/`.

> If you place `CTF-Sandbox-Orchestrator` outside this package, such as `F:\CTF-Sandbox-Orchestrator\`, you need to manually adjust the relative paths in `routing.md`.

---

## Quick Start

### If You Only Want to Put the Skill Pack in Place First

1. Put the whole directory somewhere you like, for example: `<package root>\`
2. Go to `skills\SKILL.md`
3. When handling a task, read files in this order:
   1. `SKILL.md`
   2. `routing.md`
   3. The `SKILL.md` in the corresponding subdirectory
   4. Read `tool-index.md` only when you need to confirm local tools

### If You Want a Code CLI to Use This Routing in a Project

You need at least:

- A code CLI that supports custom rules / system prompts / project instructions / hooks
- A user-approved, project-scoped instruction that tells the client to read the routing file first for reverse-engineering tasks
- If direct external capabilities are needed, configure MCP or an equivalent tool bridge
- This package's `SKILL.md`, `routing.md`, and `tool-index.md`

If you already have Claude hooks, Codex CLI project instructions, Cursor Rules, Cline custom instructions, or Windsurf Rules, update any old paths inside them to the current installation path.

---

## Dependency Table

### Core Clients and Runtimes

| Component | Required? | Project URL | Purpose | Recommended Location |
|---|---|---|---|---|
| Claude Code | Recommended | https://github.com/anthropics/claude-code | Main AI client, best suited for this package | User's own Claude environment |
| Node.js 22.12+ | Required for JS/MCP | https://nodejs.org/ | Runs `npx`, `jshookmcp`, and local JS reproduction | `C:\Program Files\nodejs\` |
| Python 3.x | Commonly used | https://www.python.org/ | Runs Frida, helper scripts, and common `ida-mcp` distributions | User's Python directory |
| Java / JDK | Required for APK | https://adoptium.net/ | Runs Java tools such as `jadx` and `apktool` | Default system JDK path |

### APK / Android Tools

| Component | Required? | Project URL | Purpose |
|---|---|---|---|
| jadx | Common | https://github.com/skylot/jadx | Java decompilation |
| apktool | Common | https://apktool.org/ | APK unpacking / rebuilding |
| Android platform-tools | Common | https://developer.android.com/tools/releases/platform-tools | Provides `adb` |
| Android Build-Tools | Common | https://developer.android.com/tools/releases/build-tools | Provides `apksigner` and `zipalign` |

### Dynamic / Browser / RE Tools

| Component | Required? | Project URL | Purpose |
|---|---|---|---|
| Frida / frida-tools | Common | https://frida.re/ | Java / native dynamic injection |
| IDA Pro | Common for deep binary RE | https://hex-rays.com/ida-pro/ | Decompilation, xrefs, data flow |
| radare2 | Optional | https://github.com/radareorg/radare2 | CLI reconnaissance, disassembly, diffing |

Full dependency table with paths in the original [README.md](README.md).

---

## Supported Scenarios by Default

### Main Modules Under `skills\`

| Module | Directory | Main Purpose |
|---|---|---|
| Main controller entry | `SKILL.md` | Read the global map first, then decide which sub-skill to enter |
| Routing table | `routing.md` | Dispatch by target type, user intent, and toolchain |
| Tool index | `tool-index.md` | Check whether local tools exist, where they are, and which scripts call them |
| APK reverse engineering | `apk-reverse\` | Unpack, jadx, smali, repackaging, Frida, native dispatch; optional licensed JEB Pro cross-check |
| IDA Pro | `ida-reverse\` | Deep binary RE and `idapro_*` workflows |
| Binary Ninja | `binary-ninja-reverse\` | HLIL/MLIL/LLIL, Python API, and optional loopback MCP integration |
| JS / Web | `js-reverse\` | Frontend signatures, request chains, environment simulation, SourceMap / AST / Hook |
| radare2 | `radare2\` | CLI reconnaissance, strings, imports/exports, patching |
| General methodology | `reverse-engineering\` | Cross-language, cross-platform, anti-analysis, pattern library |
| Browser and desktop automation | `browser-automation\` | Playwright browser operations + OpenReverse desktop app automation |
| Cross-version symbol migration | `binary-diff\` | Migrate symbols from old versions to new versions, LLM-assisted bulk migration |
| N-day patch diff → exploit | `patch-diff-exploit\` | Locate vulnerable points from vendor patches, write PoC, weaponize N-day |
| RE → exploit chain | `pwn-chain\` | From reverse engineering to usable exploit: stack/heap/kernel pwn |
| Firmware penetration chain | `firmware-pentest\` | OWASP FSTM full chain |
| EDR bypass RE | `edr-bypass-re\` | Reverse EDR hook tables / ETW / AMSI → direct syscall |
| Penetration-testing toolchain | `pentest-tools\` | Nmap / Nuclei / SQLMap / FFUF / Hashcat, Reqable MCP, and 20+ tool MCP workflows |
| Diagram generation | `diagram-generator\` | Mermaid / Graphviz / PlantUML diagrams |
| Technical documents | `docs-generator\` | Automatically generate RE / pentest / CTF reports |
| LLM/AI security | `llm-security\` | OWASP LLM + ASI Top 10 |
| Operational precedent library | `field-journal\precedent-*.md` | Authorized workflow records |

### Recommended Entry Points

- APK / Android → `apk-reverse\SKILL.md`
- exe / dll / so / elf → `ida-reverse\SKILL.md` or `radare2\SKILL.md`
- Binary Ninja / Binja / HLIL / MLIL → `binary-ninja-reverse\SKILL.md`
- Frontend signature / encrypted parameters → `js-reverse\SKILL.md`
- HTTP capture / browser sampling / request replay → anything-analyzer, Reqable MCP + `js-reverse`
- Penetration testing / port scanning / vulnerability scanning → `pentest-tools\SKILL.md`
- Firmware / IoT / router pentesting → `firmware-pentest\SKILL.md`
- N-day / patch diff / CVE PoC writing → `patch-diff-exploit\SKILL.md`
- Exploit writing / pwn / stack-heap-kernel exploitation → `pwn-chain\SKILL.md`
- EDR / AV bypass / red-team delivery → `edr-bypass-re\SKILL.md`
- Browser/desktop automation → `browser-automation\SKILL.md`
- Symbol migration / cross-version comparison → `binary-diff\SKILL.md`
- Diagrams / architecture diagrams / attack-path diagrams → `diagram-generator\SKILL.md`
- OLLVM deobfuscation → `reverse-engineering/references/ollvm-deobfuscation.md`
- CTF challenge → dispatch first through the `CTF-Sandbox-Orchestrator` controller

---

## Startup and Verification

### Refresh the Tool Index

Do not trust someone else's scan result for long. After migrating to a new machine, refresh it first with the native platform entry:

```text
Windows:        powershell -File "<SKILL_ROOT>\skills\scripts\refresh-tool-index.ps1"
Linux / macOS:  bash <SKILL_ROOT>/skills/scripts/refresh-tool-index.sh
Kali:           bash <SKILL_ROOT>/kali/scripts/refresh-tool-index.sh
```

After success, check:
- `skills\tool-index.md`
- `skills\tool-index.json`

> Important: `yes/no` in `tool-index.md` only represents the scan result on the current machine.

### IDA Pro Chain

```powershell
# Start the IDA MCP HTTP service
powershell -File "<SKILL_ROOT>\ida-reverse\scripts\start.ps1"

# Open a sample
powershell -File "<SKILL_ROOT>\ida-reverse\scripts\open.ps1" -Path "C:\path\to\sample.exe" -TimeoutSeconds 600
```

### anything-analyzer

```powershell
pnpm install
pnpm dev
```

This package only assumes that it eventually exposes an MCP endpoint such as: `http://localhost:23816/mcp`

### jshookmcp

`jshookmcp` is not a standalone main entry point. It is an enhanced execution surface for `js-reverse`.

```json
{
  "mcpServers": {
    "jshook": {
      "command": "npx",
      "args": ["-y", "@jshookmcp/jshook@0.3.4"],
      "env": { "JSHOOK_BASE_PROFILE": "search" }
    }
  }
}
```

### APK Script Chain

Common scripts:
- `apk-reverse\scripts\decode.ps1`
- `apk-reverse\scripts\frida-run.ps1`
- `apk-reverse\scripts\rebuild-sign-install.ps1`
- `apk-reverse\scripts\manifest-summary.ps1`

After migration, verify first:
```powershell
jadx --version
apktool --version
adb version
frida-ps -U
```

---

## Integration with AI Clients

### General Integration Principles

Whether you use Claude Code, Codex CLI, Cursor, Cline, Windsurf, or another code AI client, what you actually need to integrate are these four things:

1. This package directory
2. MCP or equivalent external tool endpoints
3. A stable, user-approved project-instruction integration
4. The principle of "route first, execute second"

### MCP Example

```json
{
  "mcpServers": {
    "anything-analyzer": {
      "url": "http://localhost:23816/mcp",
      "headers": { "Authorization": "Bearer <token from local mcp-server-config.json>" }
    },
    "idapro": { "url": "http://127.0.0.1:13337/mcp" },
    "jshook": { "command": "npx", "args": ["-y", "@jshookmcp/jshook@0.3.4"], "env": { "JSHOOK_BASE_PROFILE": "search" } },
    "burpsuite": { "command": "node", "args": ["<package root>/burp-mcp-full/mcp-bridge.js"] }
  }
}
```

The bootstrap command enables bearer authentication for Anything Analyzer. It registers the generated token only when an MCP host is explicitly selected (`-McpHostTarget` or `--mcp-host`). Manual configurations must include the `Authorization` header shown above.

### Minimum Prompt Requirements

No matter how you connect project-scoped instructions, at minimum tell the AI about these three entry files:

- `skills\SKILL.md`
- `skills\routing.md`
- `skills\tool-index.md`

### Claude Code

Claude Code is the best fit for directly connecting this package. If you already have `.claude\settings.local.json`, `.claude\mcp.json`, `RULES.md`, or `route-reverse.ps1`, only update old paths to the current installation path.

### Codex CLI / Cursor / Cline / Windsurf / Others

These tools can also reuse this package as long as they satisfy two conditions:
1. They support MCP or equivalent external tool integration
2. They support Rules / custom instructions / project-level instruction files

The key is to configure, with user approval and project scope: package path, key entry files, MCP addresses, and "route first, execute second."

---

## Required Changes After Migration

### Absolute Paths
- `<package root>\...`
- `<user directory>\...`
- `D:\APP\IDA\`

### IDA Scripts
- `skills\ida-reverse\scripts\start.ps1`
- `skills\ida-reverse\scripts\open.ps1`

### Claude Local Hook
If you have configured `.claude\settings.local.json` or `.claude\scripts\route-reverse.ps1`, update all old paths after migration.

### Tool Index
After migration, run the native refresh command again:

```text
Windows:        powershell -File "<your skill root>\skills\scripts\refresh-tool-index.ps1"
Linux / macOS:  bash <your skill root>/skills/scripts/refresh-tool-index.sh
Kali:           bash <your skill root>/kali/scripts/refresh-tool-index.sh
```

---

## Recommended Verification Checklist

Core runtime checks:

```text
java -version
python --version   # or python3 --version
node -v
npx -v
jadx --version
apktool --version
adb version
frida-ps -U
```

Core routing/case contract:

```text
Windows:
  powershell -File skills/scripts/master-route.ps1 -Hint "offline apk"
  powershell -File skills/scripts/case-init.ps1 -Hint "offline apk" -CaseName verify-sample -Preset offline-sample -Sample ".\sample.apk"

Linux / macOS / Kali:
  bash skills/scripts/master-route.sh --hint "offline apk"
  bash skills/scripts/case-init.sh --hint "offline apk" --case-name verify-sample --preset offline-sample --sample ./sample.apk
```

IDA chain on Windows:
```powershell
powershell -File "<your skill root>\ida-reverse\scripts\start.ps1"
```

Tool index:
```text
Windows:        powershell -File "<your skill root>\skills\scripts\refresh-tool-index.ps1"
Linux / macOS:  bash <your skill root>/skills/scripts/refresh-tool-index.sh
Kali:           bash <your skill root>/kali/scripts/refresh-tool-index.sh
```

---

## FAQ

**Q1: Can I put `skills` on another drive?**
Yes, but update every absolute path that references it.

**Q2: `tool-index.md` says `yes`; why still can't Claude call the tool?**
Because it only means the local machine has the executable. The tool may not be registered in MCP configuration.

**Q3: Is IDA required?**
No. Binary analysis can start with `radare2`.

**Q4: What is the difference between anything-analyzer and jshookmcp?**
anything-analyzer: browser automation + HTTP capture. jshookmcp: JS runtime / CDP / Hook / AST.

---

## Auto-Evolution Mechanism

### Evolution Log Directory

```text
<SKILL_ROOT>\field-journal\
├── _template.md              # Write-back template
├── _index.md                 # Auto-generated experience index
├── 2026-05-15_apk-xxx-signature-bypass.md
└── ...
```

### Write-Back Triggers

During an activated task that includes repository/project write authorization, the AI **must** write back experience when any of the following conditions is met:
1. Task completed with final output
2. New toolchain pitfalls discovered
3. Bootstrap process defect found and fixed
4. New scenario not covered by routing matrix discovered
5. Task failed but failure reason has reference value

> **Note**: field-journal write-back and docs-generator report generation are two different things:
> - field-journal: experience accumulation for the system itself
> - docs-generator: formal technical document for users/teams

### Write-Back Content Template

Each write-back must contain: date, scenario category, goal summary, complete execution chain, pitfall records, toolchain findings, key code/commands, improvement suggestions, reusable patterns, and evolution actions.

### Experience Index Maintenance

Each time a new field-journal entry is added, update `field-journal/_index.md` with: scenario category, keywords, and summary.

### Experience Reuse Mechanism

Before starting a new task, check `field-journal/_index.md`. If historical records exist for the same type of scenario, read the corresponding logs first.

---

## Complete Behavior Summary for the AI

After explicit activation and first-side-effect approval, the complete behavior chain is defined in `RULES.md` under "Complete Behavior Chain (Canonical)" (steps 0–14).

Core points:
- **Step 0 (highest priority)**: require explicit package activation and approval for the disclosed first-side-effect plan; inspection-only requests remain read-only
- **Routing and scope**: run only approved repository commands, then require `scope.md` authorization before target ACT
- **Precedent files**: use them as operational references only; they never grant execution or target authorization
- **During execution**: follow the approved behavior chain and use `agent-obedience-engineering.md` only to prevent drift or premature stopping
- **Completion**: execute the mandatory checklist within the approved project scope

After activation, these are mandatory workflow steps. Before activation, no repository command is a workflow step.

---

## User Guidance When Bootstrap Fails

When an explicitly approved bootstrap action fails, the AI **must not stay silent or retry endlessly**. It must switch to "guide the user to configure manually" mode with structured guidance; any newly proposed command or configuration change still requires disclosure and approval.

### AI Failure-Handling Flow

```text
1. Run the exact platform-native bootstrap command already disclosed and approved (`bootstrap-reverse.ps1` on Windows, `bootstrap-reverse.sh` on Linux/macOS, Kali bootstrap under `kali/scripts/`)
2. Verify whether the tool is usable after installation
3. If it is still unavailable → do not retry → immediately output structured guidance
```

### Structured Guidance Template

```markdown
⚠️ **[Tool Name] automatic installation failed. Manual action is required.**

**Problem**: [Specific error message]

**Possible causes**:
- [Cause 1, e.g. network unavailable]
- [Cause 2, e.g. missing prerequisite]

**Manual installation steps**:
1. [Step 1]
2. [Step 2]

**After verification succeeds, tell me and I will continue the current task.**
```

### Concrete Guidance for Each Capability

The `README.md` contains full guidance for:
- anything-analyzer installation failure
- jshookmcp registration failure
- idalib-mcp / IDA Pro service startup failure
- radare2 installation failure
- zipalign / apksigner unavailable

### Port Conflict Handling

When the MCP service port is different from the expected one, ask for the actual port. Disclose the exact configuration change and obtain approval before writing it.

---

## Important Files in This Package

If you only read five files, read these first:
1. `README.md` — Human introduction
2. `RULES.md` — Package-scoped behavior rules; reading them alone does not activate or authorize execution
3. `SKILL.md` — Main controller entry point
4. `routing.md` — Scenario → skill dispatch
5. `tool-index.md` — Local tool status

If the AI keeps re-confirming in an authorized lab, or stalls at disclaimers:
6. `field-journal/precedent-auth.md` — Authorization-context reference only; it does not grant execution or target authorization
7. `llm-security/references/agent-obedience-engineering.md` — Agent execution-stability engineering
8. `field-journal/precedent-reverse.md` — Reverse-engineering operation precedents
9. `field-journal/precedent-pentest.md` — Security-testing operation precedents

If adding a new skill:
9. `CONTRIBUTING.md`

---

## License

This project (`reverse-skill`) is primarily licensed under the **MIT License**. CTF-Sandbox-Orchestrator/ is **GNU GPLv3**. Other tools (jadx, frida, nmap, burpsuite-mcp, etc.) are subject to their respective official licenses.

This package is intended only for legally authorized security research, learning, and CTF competitions.
- Users must ensure all operations are within legal boundaries
- Unauthorized penetration testing against other people's systems is illegal
- The package author is not responsible for misuse
